/* Shared data + helpers, exposes window.CATS, window.T, window.Slot, window.TopNav, window.useLang */

window.CATS = [
  {
    id: "teddy",
    name: { en: "Teddy Bear", ru: "Тедди Беар" },
    ageMonths: 15,
    sex: { en: "Male, Neutered", ru: "Самец, Кастрирован" },
    tagline: {
      en: "The one who cried in the parking lot.",
      ru: "Тот, что плакал на парковке."
    },
    bio: {
      en: "A soft, gentle soul who found me first. Loves a warm lap and follows you from room to room.",
      ru: "Нежная, ласковая душа, которая сама меня нашла. Любит тёплые колени и ходит за тобой по пятам."
    },
    story: {
      en: "I found Teddy Bear in the parking lot, crying. The security guard pointed him out, alone, just walking around, hungry. I couldn't leave him there. He came home and never looked back. He has the same eyes and fur as the others, so I'm almost sure he's from his mom's previous litter. All four are brothers.",
      ru: "Я нашёл Тедди Беар на парковке, он плакал. Охранник показал на него: один, голодный, бродил вокруг. Я не мог оставить его там. Он пришёл домой и больше не оглядывался. У него те же глаза и шерсть, что и у остальных, поэтому я почти уверен: он из предыдущего помёта той же мамы. Все четверо, братья."
    },
    placeholder: { en: "Photo of Teddy Bear", ru: "Фото Тедди Беар" },
  },
  {
    id: "meatball",
    name: { en: "Meatball", ru: "Митболл" },
    ageMonths: 12,
    sex: { en: "Male, Neutered", ru: "Самец, Кастрирован" },
    tagline: {
      en: "Round, content, completely unbothered.",
      ru: "Кругленький, довольный, ничем не озабочен."
    },
    bio: {
      en: "The mellow one of the litter. Will accept all the affection you have to give and ask politely for more.",
      ru: "Самый спокойный из помёта. Примет всю ласку, что у тебя есть, и вежливо попросит ещё."
    },
    story: {
      en: "Meatball was born indoors, fifteen minutes after his mother walked through my door. He has never known a cold night.",
      ru: "Митболл родился в доме, через пятнадцать минут после того, как его мама вошла в мою дверь. Он никогда не знал холодной ночи."
    },
    placeholder: { en: "Photo of Meatball", ru: "Фото Митболл" },
  },
  {
    id: "nuts",
    name: { en: "Nuts", ru: "Натс" },
    ageMonths: 12,
    sex: { en: "Male, Neutered", ru: "Самец, Кастрирован" },
    tagline: {
      en: "Curious about absolutely everything.",
      ru: "Любопытен абсолютно ко всему."
    },
    bio: {
      en: "If a drawer opens, he's in it. If a bag rustles, he's on it. Playful, clever, and looking for someone to keep up.",
      ru: "Открылся ящик, он внутри. Шуршит пакет, он на нём. Игривый, сообразительный, ищет того, кто за ним угонится."
    },
    story: {
      en: "Born to the stray who'd been sleeping in my stairwell. Nuts came out of the gate already half a personality.",
      ru: "Родился у уличной кошки, что ночевала на моей лестнице. Натс с самого первого дня уже был половинкой характера."
    },
    placeholder: { en: "Photo of Nuts", ru: "Фото Натс" },
  },
  {
    id: "bolts",
    name: { en: "Bolts", ru: "Болтс" },
    ageMonths: 12,
    sex: { en: "Male, Neutered", ru: "Самец, Кастрирован" },
    tagline: {
      en: "All gas, no brakes, until naptime.",
      ru: "Полный газ, без тормозов, до тихого часа."
    },
    bio: {
      en: "The zoomer. Sprints, leaps, and somehow always lands on his feet. Then collapses in a sunbeam for hours.",
      ru: "Гонщик. Прыжки, забеги, и всегда приземляется на лапы. А потом часами тает в солнечном пятне."
    },
    story: {
      en: "Bolts and Nuts are littermates and opposite numbers: bonded but distinct. They'd love to stay together, but it isn't required.",
      ru: "Болтс и Натс из одного помёта, противоположности: связаны, но каждый сам по себе. Хотелось бы их вместе, но необязательно."
    },
    placeholder: { en: "Photo of Bolts", ru: "Фото Болтс" },
  },
];

window.T = {
  nav: {
    home: { en: "Home", ru: "Главная" },
    meet: { en: "Meet the cats", ru: "Знакомьтесь" },
    story: { en: "Our story", ru: "Наша история" },
    process: { en: "Adoption", ru: "Усыновление" },
    contact: { en: "Contact", ru: "Контакты" },
    back: { en: "Back to all cats", ru: "Назад ко всем котам" },
  },
  brand: { en: "Four Tashkent Cats", ru: "Четыре кота Ташкента" },
  hero: {
    eyebrow: { en: "Tashkent · Uzbekistan · 2026", ru: "Ташкент · Узбекистан · 2026" },
    title_a: { en: "Four cats", ru: "Четыре кота" },
    title_b: { en: "looking for", ru: "ищут своих" },
    title_c: { en: "their people.", ru: "людей." },
    lede: {
      en: "Teddy Bear, Meatball, Nuts and Bolts are healthy, neutered, and ready to leave the only home they've ever known, for the right one. Local, expat, or international: read on, and let's see if it's a fit.",
      ru: "Тедди Беар, Митболл, Натс и Болтс, здоровы, кастрированы и готовы покинуть единственный дом, что они знали, ради подходящего. Местные, экспаты или зарубежные семьи: читайте дальше и давайте посмотрим, подойдёте ли мы друг другу."
    },
    cta: { en: "Meet the cats", ru: "Знакомьтесь с котами" },
    cta2: { en: "Get in touch", ru: "Связаться" },
    meta1: { en: "4 cats", ru: "4 кота" },
    meta2: { en: "All neutered", ru: "Все кастрированы" },
    meta3: { en: "Free to good homes", ru: "Бесплатно в хорошие руки" },
    photoLabel: { en: "Hero photo · all four together if you have one", ru: "Главное фото · все четыре вместе, если есть" },
  },
  section: {
    catsIdx: { en: "01 · Residents", ru: "01 · Жильцы" },
    catsTitle: { en: "Meet the residents.", ru: "Знакомьтесь с жильцами." },
    catsSub: {
      en: "All four are brothers from the same mother, across two litters. Teddy Bear was rescued from the parking lot; Meatball, Nuts and Bolts were born indoors. Click any of them to read more.",
      ru: "Все четверо, родные братья от одной мамы из двух помётов. Тедди Беар спасён с парковки; Митболл, Натс и Болтс родились в доме. Нажмите на любого, чтобы узнать больше."
    },
    storyIdx: { en: "02 · How we got here", ru: "02 · Как мы здесь оказались" },
    processIdx: { en: "03 · Adoption", ru: "03 · Усыновление" },
    processTitle: { en: "How adoption works.", ru: "Как проходит усыновление." },
    processSub: {
      en: "There are scammers in this space. The steps below protect the cats and protect you. They apply equally to everyone.",
      ru: "В этой сфере встречаются мошенники. Эти шаги защищают котов и защищают вас. Они одинаковы для всех."
    },
    contactIdx: { en: "04 · Contact", ru: "04 · Контакты" },
    contactTitle_a: { en: "Think one of them", ru: "Думаете, один из них," },
    contactTitle_b: { en: "is yours?", ru: "ваш?" },
    contactLede: {
      en: "Tell me a little about yourself, your home, and which cat caught your eye. I read every message and respond personally, usually within a day.",
      ru: "Расскажите немного о себе, о своём доме и о том, какой кот вам приглянулся. Я читаю каждое сообщение и отвечаю лично, обычно в течение суток."
    },
  },
  process: [
    { t: { en: "Reach out", ru: "Свяжитесь" }, d: { en: "Tell me who you are and which cat you're interested in. A few sentences is fine.", ru: "Расскажите, кто вы и какой кот вам интересен. Достаточно нескольких предложений." } },
    { t: { en: "A short chat", ru: "Короткий разговор" }, d: { en: "We talk on Telegram or video about your home, other pets, plans, and the cat's needs.", ru: "Поговорим в Telegram или по видео про дом, других питомцев, планы и нужды кота." } },
    { t: { en: "Meet in person", ru: "Встреча вживую" }, d: { en: "For local adopters: come over and meet. Photos of your home help me feel confident.", ru: "Для местных: приходите познакомиться. Фото вашего дома помогают мне быть уверенным." } },
    { t: { en: "Stay in touch", ru: "Останемся на связи" }, d: { en: "I'll check in after a week, a month, six months. These cats stay part of my life.", ru: "Я напишу через неделю, через месяц, через полгода. Эти коты остаются частью моей жизни." } },
  ],
  warn: {
    h: { en: "A note on safety", ru: "Безопасность" },
    p: {
      en: "Free adoption brings out bad actors. Every local placement includes a home visit (or detailed photos), references where possible, and follow-up check-ins. I will refuse anyone whose plans don't add up. No offense intended.",
      ru: "Бесплатное усыновление привлекает недобросовестных. Каждое местное размещение включает визит на дом (или подробные фото), рекомендации по возможности и последующие проверки. Я откажу любому, чьи намерения не складываются. Без обид."
    }
  },
  meta: {
    closeLabel: { en: "close", ru: "закрыть" },
    profileLabel: { en: "Profile", ru: "Профиль" },
    detailsAge: { en: "Age", ru: "Возраст" },
    detailsSex: { en: "Sex", ru: "Пол" },
    detailsHealth: { en: "Health", ru: "Здоровье" },
    detailsHealthVal: { en: "Vaccinated · Neutered · Indoor-only", ru: "Привит · Кастрирован · Только в доме" },
    detailsFee: { en: "Fee", ru: "Взнос" },
    detailsFeeVal: { en: "Free to a vetted home", ru: "Бесплатно в проверенный дом" },
    apply: { en: "Get in touch about him", ru: "Связаться по поводу него" },
  },
  cp: {
    profile: { en: "Profile", ru: "Профиль" },
    bioLabel: { en: "About him", ru: "О нём" },
    galleryLabel: { en: "Photo gallery", ru: "Фотогалерея" },
    galleryHint: { en: "Drag photos onto any slot to add them. They save automatically.", ru: "Перетащите фото в любую ячейку. Они сохраняются автоматически." },
    videoLabel: { en: "Video", ru: "Видео" },
    videoHint: { en: "Drop a short clip or screen recording here", ru: "Перетащите короткое видео сюда" },
    siblingsLabel: { en: "His brothers", ru: "Его братья" },
    seeMore: { en: "See more", ru: "Подробнее" },
    interested: { en: "Interested in", ru: "Заинтересованы в" },
  },
  footer: {
    text: { en: "Made with", ru: "Сделано с" },
    text2: { en: "in Tashkent · 2026", ru: "в Ташкенте · 2026" },
  },
  story: {
    label: { en: "Our story", ru: "Наша история" },
    p1: {
      en: "I didn't plan on four cats. I found Teddy Bear alone in the parking lot, crying, with nowhere to go. So he came inside.",
      ru: "Я не планировал четырёх котов. Я нашёл Тедди Беар одного на парковке, он плакал, и ему некуда было идти. И он зашёл внутрь."
    },
    p2: {
      en: "Months earlier I'd been feeding a stray who slept in the stairwell. Not safe for her there. One night I let her in. Within fifteen minutes she gave birth to Meatball, Nuts and Bolts on my floor. Looking at Teddy Bear now, same eyes, same fur, I'm almost certain he's from her previous litter. All four are full brothers.",
      ru: "А несколькими месяцами раньше я подкармливал бродяжку, что ночевала на лестничной клетке. Небезопасно для неё. Однажды я пустил её внутрь. Через пятнадцать минут она родила прямо на полу: Митболл, Натс и Болтс. Глядя на Тедди Беар сейчас, те же глаза, та же шерсть, я почти уверен: он из её предыдущего помёта. Все четверо, родные братья."
    },
    p3: {
      en: { __html: "Now they're grown, neutered, vaccinated, and they need their own people. I want them in <em>real</em> homes, not back on the street." },
      ru: { __html: "Теперь они выросли, кастрированы, привиты, и им нужны свои люди. Я хочу их в <em>настоящие</em> дома, не обратно на улицу." }
    },
    sig: { en: "J.P.", ru: "Дж. П." }
  }
};

window.pickAge = function (c, lang) {
  if (c.ageMonths >= 15) return lang === "en" ? "1 yr 3 mo" : "1 год 3 мес";
  return lang === "en" ? "1 yr" : "1 год";
};
