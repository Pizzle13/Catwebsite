/* Homepage: hero, cat grid (links to Cat.html), story, process, contact */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "palette": "cream",
  "heroLayout": "split",
  "cardStyle": "editorial",
  "lang": "en"
}/*EDITMODE-END*/;

const CATS = window.CATS;
const T = window.T;
const pickAge = window.pickAge;

function Slot({ id, label, lang }) {
  return <image-slot id={`slot-${id}`} placeholder={label[lang]} shape="rect" />;
}

function TopNav({ lang, setLang }) {
  return (
    <nav className="top">
      <a className="brand" href="Cat Adoption.html">
        <div className="mark">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M5 9 C5 5, 8 4, 10 6 L 12 8 L 14 6 C 16 4, 19 5, 19 9 C 19 14, 14 18, 12 18 C 10 18, 5 14, 5 9 Z" fill="currentColor"/>
          </svg>
        </div>
        <div className="name">{T.brand[lang]}</div>
      </a>
      <div className="links">
        <a href="#cats">{T.nav.meet[lang]}</a>
        <a href="#story">{T.nav.story[lang]}</a>
        <a href="#process">{T.nav.process[lang]}</a>
        <a href="#contact">{T.nav.contact[lang]}</a>
        <div className="lang">
          <button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>EN</button>
          <button className={lang === "ru" ? "on" : ""} onClick={() => setLang("ru")}>RU</button>
        </div>
      </div>
    </nav>
  );
}

function Hero({ lang, layout }) {
  const title = (
    <h1>
      {T.hero.title_a[lang]} <em>{T.hero.title_b[lang]}</em> {T.hero.title_c[lang]}
    </h1>
  );
  const ctaRow = (
    <div className="hero-cta">
      <a href="#cats" className="btn btn-primary">{T.hero.cta[lang]} <span className="arr">→</span></a>
      <a href="#contact" className="btn btn-ghost">{T.hero.cta2[lang]}</a>
    </div>
  );
  const meta = (
    <div className="hero-meta">
      <span><span className="dot"></span>{T.hero.meta1[lang]}</span>
      <span><span className="dot"></span>{T.hero.meta2[lang]}</span>
      <span><span className="dot"></span>{T.hero.meta3[lang]}</span>
    </div>
  );

  if (layout === "stack") {
    return (
      <header className="hero hero-stack" data-screen-label="01 Hero">
        <div>
          <div className="eyebrow">{T.hero.eyebrow[lang]}</div>
          {title}<p className="lede">{T.hero.lede[lang]}</p>{ctaRow}{meta}
        </div>
        <div className="hero-photo"><Slot id="hero" label={T.hero.photoLabel} lang={lang} /></div>
      </header>
    );
  }
  if (layout === "overlay") {
    return (
      <header className="hero hero-overlay" data-screen-label="01 Hero">
        <div className="hero-photo"><Slot id="hero" label={T.hero.photoLabel} lang={lang} /></div>
        <div className="hero-text">
          <div className="eyebrow">{T.hero.eyebrow[lang]}</div>
          {title}<p className="lede">{T.hero.lede[lang]}</p>{ctaRow}
        </div>
      </header>
    );
  }
  return (
    <header className="hero hero-split" data-screen-label="01 Hero">
      <div>
        <div className="eyebrow">{T.hero.eyebrow[lang]}</div>
        {title}<p className="lede">{T.hero.lede[lang]}</p>{ctaRow}{meta}
      </div>
      <div className="hero-photo"><Slot id="hero" label={T.hero.photoLabel} lang={lang} /></div>
    </header>
  );
}

function CatCard({ cat, style, lang, idx }) {
  const age = pickAge(cat, lang);
  const slot = <Slot id={cat.id} label={cat.placeholder} lang={lang} />;
  const href = `Cat.html?id=${cat.id}`;

  if (style === "polaroid") {
    return (
      <a className="card-polaroid" href={href}>
        <div className="ph">{slot}</div>
        <div className="meta"><h3>{cat.name[lang]}</h3><div className="age">{age}</div></div>
      </a>
    );
  }
  if (style === "stacked") {
    return (
      <a className="card-stacked" href={href}>
        <div className="ph">{slot}
          <div className="label"><h3>{cat.name[lang]}</h3><div className="age">{age}</div></div>
        </div>
      </a>
    );
  }
  return (
    <a className="card-editorial" href={href}>
      <div className="ph">{slot}</div>
      <div className="meta"><h3>{cat.name[lang]}</h3><div className="age">{String(idx + 1).padStart(2, "0")} · {age}</div></div>
      <p className="bio">{cat.bio[lang]}</p>
    </a>
  );
}

function Story({ lang }) {
  return (
    <section className="story-section" id="story" data-screen-label="02 Story">
      <div className="inner">
        <div className="label">{T.section.storyIdx[lang]}</div>
        <div>
          <p>{T.story.p1[lang]}</p>
          <p>{T.story.p2[lang]}</p>
          <p dangerouslySetInnerHTML={{ __html: T.story.p3[lang].__html }} />
          <div className="sig">{T.story.sig[lang]}</div>
        </div>
      </div>
    </section>
  );
}

function Process({ lang }) {
  return (
    <section className="process" id="process" data-screen-label="03 Process">
      <div className="section-header" style={{padding: 0, margin: "0 0 8px"}}>
        <div>
          <div className="index">{T.section.processIdx[lang]}</div>
          <h2>{T.section.processTitle[lang]}</h2>
        </div>
        <div className="right">{T.section.processSub[lang]}</div>
      </div>
      <div className="process-grid">
        {T.process.map((s, i) => (
          <div className="step" key={i}>
            <div className="num">{String(i + 1).padStart(2, "0")}</div>
            <h4>{s.t[lang]}</h4>
            <p>{s.d[lang]}</p>
          </div>
        ))}
      </div>
      <div className="warning">
        <div className="ico">!</div>
        <div><h4>{T.warn.h[lang]}</h4><p>{T.warn.p[lang]}</p></div>
      </div>
    </section>
  );
}

function Contact({ lang }) {
  const channels = [
    { label: "Telegram", value: "@MrBhikarry", href: "https://t.me/MrBhikarry" },
    { label: "Email", value: "jpbhikarry@gmail.com", href: "mailto:jpbhikarry@gmail.com" },
    { label: { en: "Phone / WhatsApp", ru: "Телефон / WhatsApp" }, value: "+998 90 063 5726", href: "https://wa.me/998900635726" },
  ];
  return (
    <section className="contact" id="contact" data-screen-label="04 Contact">
      <div className="contact-grid">
        <div>
          <div style={{fontFamily:"'JetBrains Mono', monospace", fontSize:11, letterSpacing:".14em", textTransform:"uppercase", color:"var(--ink-mute)", marginBottom: 14}}>{T.section.contactIdx[lang]}</div>
          <h2>{T.section.contactTitle_a[lang]} <em>{T.section.contactTitle_b[lang]}</em></h2>
          <p className="lede">{T.section.contactLede[lang]}</p>
        </div>
        <div className="contact-list">
          {channels.map((c, i) => (
            <a key={i} href={c.href} target="_blank">
              <span className="ch-label">{typeof c.label === "string" ? c.label : c.label[lang]}</span>
              <span className="ch-value">{c.value}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function App() {
  const [tweaks, setTweak] = window.useTweaks(TWEAK_DEFAULTS);
  const { TweaksPanel, TweakSection, TweakRadio, TweakSelect } = window;

  React.useEffect(() => {
    document.documentElement.setAttribute("data-palette", tweaks.palette);
    try { localStorage.setItem("site.lang", tweaks.lang); localStorage.setItem("site.palette", tweaks.palette); } catch(e){}
  }, [tweaks.palette, tweaks.lang]);

  const lang = tweaks.lang;
  const setLang = (l) => setTweak("lang", l);

  return (
    <>
      <TopNav lang={lang} setLang={setLang} />
      <Hero lang={lang} layout={tweaks.heroLayout} />
      <div className="section-header" id="cats">
        <div>
          <div className="index">{T.section.catsIdx[lang]}</div>
          <h2>{T.section.catsTitle[lang]}</h2>
        </div>
        <div className="right">{T.section.catsSub[lang]}</div>
      </div>
      <div className="cats-wrap">
        <div className={`cats-grid ${tweaks.cardStyle}`}>
          {CATS.map((cat, i) => (
            <CatCard key={cat.id} cat={cat} idx={i} style={tweaks.cardStyle} lang={lang} />
          ))}
        </div>
      </div>
      <Story lang={lang} />
      <Process lang={lang} />
      <Contact lang={lang} />
      <footer>{T.footer.text[lang]} <span className="heart">♡</span> {T.footer.text2[lang]}</footer>

      <TweaksPanel title="Tweaks">
        <TweakSection label="Language">
          <TweakRadio label="Site language" value={tweaks.lang}
            options={[{ value: "en", label: "English" }, { value: "ru", label: "Русский" }]}
            onChange={(v) => setTweak("lang", v)} />
        </TweakSection>
        <TweakSection label="Palette">
          <TweakSelect label="Color theme" value={tweaks.palette}
            options={[
              { value: "cream", label: "Cream + terracotta (warm)" },
              { value: "sage", label: "Sage + cream (calm)" },
              { value: "dusk", label: "Dusk (dark warm)" },
              { value: "plum", label: "Plum + blush (soft)" },
            ]}
            onChange={(v) => setTweak("palette", v)} />
        </TweakSection>
        <TweakSection label="Hero">
          <TweakSelect label="Hero layout" value={tweaks.heroLayout}
            options={[
              { value: "split", label: "Split, text + portrait" },
              { value: "stack", label: "Stacked, wide photo below" },
              { value: "overlay", label: "Overlay, text on photo" },
            ]}
            onChange={(v) => setTweak("heroLayout", v)} />
        </TweakSection>
        <TweakSection label="Cat cards">
          <TweakSelect label="Card style" value={tweaks.cardStyle}
            options={[
              { value: "editorial", label: "Editorial, 2-up with bio" },
              { value: "polaroid", label: "Polaroid, 4-up tilted" },
              { value: "stacked", label: "Stacked, 4-up label overlay" },
            ]}
            onChange={(v) => setTweak("cardStyle", v)} />
        </TweakSection>
      </TweaksPanel>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App />);
