/* Individual cat profile page. Reads ?id= and renders hero, bio, gallery, video slot, siblings, contact. */

const CATS = window.CATS;
const T = window.T;
const pickAge = window.pickAge;

function getParam(name) {
  const m = new URLSearchParams(window.location.search);
  return m.get(name);
}

function getLang() {
  try {
    const stored = localStorage.getItem("site.lang");
    if (stored === "en" || stored === "ru") return stored;
  } catch (e) {}
  return "en";
}

function getPalette() {
  try {
    const stored = localStorage.getItem("site.palette");
    if (stored) return stored;
  } catch (e) {}
  return "cream";
}

function Slot(props) {
  return <image-slot
    id={props.id}
    placeholder={props.placeholder}
    shape={props.shape || "rect"}
  />;
}

function TopNav({ lang, setLang }) {
  return (
    <nav className="top">
      <a className="brand" href="Cat Adoption.html">
        <div className="mark">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
            <path d="M5 9 C5 5, 8 4, 10 6 L 12 8 L 14 6 C 16 4, 19 5, 19 9 C 19 14, 14 18, 12 18 C 10 18, 5 14, 5 9 Z" fill="currentColor"/>
          </svg>
        </div>
        <div className="name">{T.brand[lang]}</div>
      </a>
      <div className="links">
        <a href="Cat Adoption.html#cats">{T.nav.meet[lang]}</a>
        <a href="Cat Adoption.html#story">{T.nav.story[lang]}</a>
        <a href="Cat Adoption.html#process">{T.nav.process[lang]}</a>
        <a href="Cat Adoption.html#contact">{T.nav.contact[lang]}</a>
        <div className="lang">
          <button className={lang === "en" ? "on" : ""} onClick={() => setLang("en")}>EN</button>
          <button className={lang === "ru" ? "on" : ""} onClick={() => setLang("ru")}>RU</button>
        </div>
      </div>
    </nav>
  );
}

function CatHero({ cat, lang, idx }) {
  return (
    <header className="cp-hero" data-screen-label={`Cat ${cat.id}`}>
      <div className="cp-hero-grid">
        <div>
          <div className="cp-hero" style={{padding:0}}>
            <div className="num">
              {T.cp.profile[lang]} · {String(idx + 1).padStart(2, "0")} / 04
            </div>
          </div>
          <h1>{cat.name[lang]}</h1>
          <div className="tagline">"{cat.tagline[lang]}"</div>
          <dl>
            <dt>{T.meta.detailsAge[lang]}</dt><dd>{pickAge(cat, lang)}</dd>
            <dt>{T.meta.detailsSex[lang]}</dt><dd>{cat.sex[lang]}</dd>
            <dt>{T.meta.detailsHealth[lang]}</dt><dd>{T.meta.detailsHealthVal[lang]}</dd>
            <dt>{T.meta.detailsFee[lang]}</dt><dd>{T.meta.detailsFeeVal[lang]}</dd>
          </dl>
          <div className="hero-cta">
            <a href="Cat Adoption.html#contact" className="btn btn-primary">{T.meta.apply[lang]} <span className="arr">→</span></a>
          </div>
        </div>
        <div className="ph"><Slot id={`cp-hero-${cat.id}`} placeholder={cat.placeholder[lang]} /></div>
      </div>
    </header>
  );
}

function Bio({ cat, lang }) {
  return (
    <section className="cp-bio">
      <div className="label">{T.cp.bioLabel[lang]}</div>
      <p>{cat.story[lang]}</p>
      <p>{cat.bio[lang]}</p>
    </section>
  );
}

const GALLERY_LAYOUT = [
  { cls: "feature", key: "g1" },
  { cls: "tall",    key: "g2" },
  { cls: "",        key: "g3" },
  { cls: "",        key: "g4" },
  { cls: "wide",    key: "g5" },
  { cls: "",        key: "g6" },
  { cls: "",        key: "g7" },
];

function Gallery({ cat, lang }) {
  const ph = lang === "en" ? "Drop a photo" : "Перетащите фото";
  return (
    <section className="cp-gallery">
      <div className="section-header" style={{padding: 0, margin: "0 0 20px", maxWidth: "100%"}}>
        <div>
          <div className="index">{T.cp.galleryLabel[lang]}</div>
        </div>
        <div className="right">{T.cp.galleryHint[lang]}</div>
      </div>
      <div className="cp-gal-grid">
        {GALLERY_LAYOUT.map((slot) => (
          <div key={slot.key} className={`cp-gal-slot ${slot.cls}`}>
            <Slot id={`gal-${cat.id}-${slot.key}`} placeholder={ph} />
          </div>
        ))}
      </div>
    </section>
  );
}

function VideoSlot({ cat, lang }) {
  return (
    <section className="cp-video">
      <div className="section-header" style={{padding: 0, margin: "0 0 20px", maxWidth: "100%"}}>
        <div>
          <div className="index">{T.cp.videoLabel[lang]}</div>
        </div>
        <div className="right">{T.cp.videoHint[lang]}</div>
      </div>
      <div className="cp-video-frame">
        <Slot id={`vid-${cat.id}`} placeholder={lang === "en" ? `Video of ${cat.name.en}` : `Видео ${cat.name.ru}`} />
        <div className="lbl" style={{position:"absolute", pointerEvents:"none"}}>
          <div className="play"></div>
          <div>{lang === "en" ? "Drag a video clip here" : "Перетащите видео сюда"}</div>
        </div>
      </div>
    </section>
  );
}

function Siblings({ current, lang }) {
  const others = CATS.filter(c => c.id !== current.id);
  return (
    <section className="cp-siblings">
      <div className="section-header" style={{padding: 0, margin: "0 0 8px", maxWidth: "100%"}}>
        <div>
          <div className="index">{T.cp.siblingsLabel[lang]}</div>
        </div>
      </div>
      <div className="cp-sib-grid">
        {others.map(c => (
          <a key={c.id} className="cp-sib" href={`Cat.html?id=${c.id}`}>
            <div className="ph"><Slot id={`sib-thumb-${c.id}`} placeholder={c.placeholder[lang]} /></div>
            <div className="meta">
              <h4>{c.name[lang]}</h4>
              <div className="more">{T.cp.seeMore[lang]} →</div>
            </div>
          </a>
        ))}
      </div>
    </section>
  );
}

function Contact({ lang, cat }) {
  const channels = [
    { label: "Telegram", value: "@MrBhikarry", href: "https://t.me/MrBhikarry" },
    { label: "Email", value: "jpbhikarry@gmail.com", href: "mailto:jpbhikarry@gmail.com" },
    { label: { en: "Phone / WhatsApp", ru: "Телефон / WhatsApp" }, value: "+998 90 063 5726", href: "https://wa.me/998900635726" },
  ];
  return (
    <section className="contact">
      <div className="contact-grid">
        <div>
          <div style={{fontFamily:"'JetBrains Mono', monospace", fontSize:11, letterSpacing:".14em", textTransform:"uppercase", color:"var(--ink-mute)", marginBottom: 14}}>
            {T.cp.interested[lang]} {cat.name[lang]}?
          </div>
          <h2>{T.section.contactTitle_a[lang]} <em>{T.section.contactTitle_b[lang]}</em></h2>
          <p className="lede">{T.section.contactLede[lang]}</p>
        </div>
        <div className="contact-list">
          {channels.map((c, i) => (
            <a key={i} href={c.href} target="_blank">
              <span className="ch-label">{typeof c.label === "string" ? c.label : c.label[lang]}</span>
              <span className="ch-value">{c.value}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}

function NotFound({ lang }) {
  return (
    <div style={{padding:"120px 40px", maxWidth: 720, margin: "0 auto", textAlign: "center"}}>
      <h1 style={{fontFamily:"'Instrument Serif', serif", fontSize: 72, margin: "0 0 18px"}}>
        {lang === "en" ? "Cat not found" : "Кот не найден"}
      </h1>
      <p style={{color:"var(--ink-soft)", marginBottom: 32}}>
        {lang === "en"
          ? "We don't have a profile for that cat. Try one of the four."
          : "У нас нет такого кота. Попробуйте одного из четырёх."}
      </p>
      <a className="btn btn-primary" href="Cat Adoption.html">← {T.nav.back[lang]}</a>
    </div>
  );
}

function App() {
  const [lang, setLangState] = React.useState(getLang());
  const setLang = (l) => {
    setLangState(l);
    try { localStorage.setItem("site.lang", l); } catch (e) {}
  };

  React.useEffect(() => {
    document.documentElement.setAttribute("data-palette", getPalette());
  }, []);

  const id = getParam("id");
  const idx = CATS.findIndex(c => c.id === id);
  const cat = idx >= 0 ? CATS[idx] : null;

  React.useEffect(() => {
    if (cat) document.title = `${cat.name[lang]} · Four Tashkent Cats`;
  }, [cat, lang]);

  if (!cat) {
    return (
      <>
        <TopNav lang={lang} setLang={setLang} />
        <NotFound lang={lang} />
      </>
    );
  }

  return (
    <>
      <TopNav lang={lang} setLang={setLang} />
      <div className="cp-wrap">
        <a className="back-link" href="Cat Adoption.html#cats">
          <span className="arr">←</span> {T.nav.back[lang]}
        </a>
      </div>
      <CatHero cat={cat} lang={lang} idx={idx} />
      <Bio cat={cat} lang={lang} />
      <Gallery cat={cat} lang={lang} />
      <VideoSlot cat={cat} lang={lang} />
      <Siblings current={cat} lang={lang} />
      <Contact lang={lang} cat={cat} />
      <footer>{T.footer.text[lang]} <span className="heart">♡</span> {T.footer.text2[lang]}</footer>
    </>
  );
}

const root = ReactDOM.createRoot(document.getElementById("app"));
root.render(<App />);
